package com.example.a19dhjetor2024;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ScrollView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONObject;

public class SecurityQuestionsActivity extends AppCompatActivity {
    private static final String[] DEFAULT_QUESTIONS = {
        "What was your favorite place to visit as a child?",
        "What was the title of a book, movie, or show you loved when you were younger?",
        "What food did you really dislike as a kid but later started liking?",
        "What was the nickname of someone close to you growing up?",
        "What was a hobby or activity you enjoyed in school?"
    };
    
    private EditText[] answerInputs;
    private TextView[] questionTexts;
    private Button submitButton;
    private ScrollView scrollView;
    private String email;
    private String name;
    private String password;
    private boolean isRegistration;
    private String deviceFingerprint;
    private String deviceModel;
    private String networkType;
    private String networkSSID;
    private String ipAddress;
    private String suspiciousReason;
    private boolean isTrustedDevice;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_security_questions);

        // Get data from intent
        email = getIntent().getStringExtra("email");
        isRegistration = getIntent().getBooleanExtra("isRegistration", false);
        
        if (isRegistration) {
            name = getIntent().getStringExtra("name");
            password = getIntent().getStringExtra("password");
        } else {
            deviceFingerprint = getIntent().getStringExtra("deviceFingerprint");
            deviceModel = getIntent().getStringExtra("deviceModel");
            networkType = getIntent().getStringExtra("networkType");
            networkSSID = getIntent().getStringExtra("networkSSID");
            ipAddress = getIntent().getStringExtra("ipAddress");
            suspiciousReason = getIntent().getStringExtra("suspiciousReason");
            isTrustedDevice = getIntent().getBooleanExtra("isTrustedDevice", false);
        }

        apiService = new ApiService(this);

        // Initialize views
        questionTexts = new TextView[5];
        answerInputs = new EditText[5];
        
        questionTexts[0] = findViewById(R.id.question1Text);
        questionTexts[1] = findViewById(R.id.question2Text);
        questionTexts[2] = findViewById(R.id.question3Text);
        questionTexts[3] = findViewById(R.id.question4Text);
        questionTexts[4] = findViewById(R.id.question5Text);
        
        answerInputs[0] = findViewById(R.id.answer1Input);
        answerInputs[1] = findViewById(R.id.answer2Input);
        answerInputs[2] = findViewById(R.id.answer3Input);
        answerInputs[3] = findViewById(R.id.answer4Input);
        answerInputs[4] = findViewById(R.id.answer5Input);
        
        submitButton = findViewById(R.id.submitButton);
        scrollView = findViewById(R.id.scrollView);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (isRegistration) {
            // Show default questions for registration
            for (int i = 0; i < 5; i++) {
                questionTexts[i].setText(DEFAULT_QUESTIONS[i]);
            }
            submitButton.setText("Register & Verify");
        } else {
            // Load questions from backend for verification
            loadSecurityQuestions();
            submitButton.setText("Verify");
        }

        submitButton.setOnClickListener(v -> handleSubmit());
    }

    private void loadSecurityQuestions() {
        Toast.makeText(this, "Loading security questions...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            ApiService.ApiResponse response = apiService.getSecurityQuestions(email);
            runOnUiThread(() -> {
                if (response.success && response.data != null && !response.data.isEmpty()) {
                    try {
                        JSONObject json = new JSONObject(response.data);
                        JSONArray questions = json.getJSONObject("data").getJSONArray("questions");
                        for (int i = 0; i < 5; i++) {
                            questionTexts[i].setText(questions.getString(i));
                        }
                        Toast.makeText(this, "Questions loaded", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        android.util.Log.e("SecurityQuestions", "Error parsing questions, using defaults: " + e.getMessage(), e);
                        // Fall back to default questions
                        useDefaultQuestions();
                    }
                } else {
                    // API call failed or endpoint doesn't exist - use default questions
                    android.util.Log.w("SecurityQuestions", "Failed to load questions from API: " + (response != null ? response.message : "null response"));
                    useDefaultQuestions();
                }
            });
        }).start();
    }
    
    private void useDefaultQuestions() {
        // Use default questions as fallback
        for (int i = 0; i < 5; i++) {
            questionTexts[i].setText(DEFAULT_QUESTIONS[i]);
        }
        Toast.makeText(this, "Using default security questions", Toast.LENGTH_SHORT).show();
    }

    private void handleSubmit() {
        // Validate all answers
        for (int i = 0; i < 5; i++) {
            if (TextUtils.isEmpty(answerInputs[i].getText().toString().trim())) {
                Toast.makeText(this, "Please answer all questions", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (isRegistration) {
            handleRegistration();
        } else {
            handleVerification();
        }
    }

    private void handleRegistration() {
        Toast.makeText(this, "Registering...", Toast.LENGTH_SHORT).show();
        
        new Thread(() -> {
            try {
                // Prepare security questions JSON
                JSONArray securityQuestions = new JSONArray();
                for (int i = 0; i < 5; i++) {
                    JSONObject qa = new JSONObject();
                    qa.put("question", DEFAULT_QUESTIONS[i]);
                    qa.put("answer", answerInputs[i].getText().toString().trim());
                    securityQuestions.put(qa);
                }
                
                // Register with security questions
                ApiService.ApiResponse registerResponse = apiService.registerWithQuestions(name, email, password, securityQuestions);
                
                runOnUiThread(() -> {
                    if (registerResponse.success) {
                        // Now verify the security questions immediately
                        verifySecurityQuestionsForRegistration();
                    } else {
                        Toast.makeText(this, "Registration failed: " + registerResponse.message, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void verifySecurityQuestionsForRegistration() {
        Toast.makeText(this, "Verifying...", Toast.LENGTH_SHORT).show();
        
        new Thread(() -> {
            try {
                JSONArray answers = new JSONArray();
                for (int i = 0; i < 5; i++) {
                    answers.put(answerInputs[i].getText().toString().trim());
                }
                
                ApiService.ApiResponse verifyResponse = apiService.verifySecurityQuestions(email, answers);
                
                runOnUiThread(() -> {
                    if (verifyResponse.success) {
                        Toast.makeText(this, "Registration successful! Please login.", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(SecurityQuestionsActivity.this, Login.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(this, "Verification failed: " + verifyResponse.message, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void handleVerification() {
        Toast.makeText(this, "Verifying...", Toast.LENGTH_SHORT).show();
        
        new Thread(() -> {
            try {
                JSONArray answers = new JSONArray();
                for (int i = 0; i < 5; i++) {
                    answers.put(answerInputs[i].getText().toString().trim());
                }
                
                ApiService.ApiResponse verifyResponse = apiService.verifySecurityQuestions(email, answers);
                
                runOnUiThread(() -> {
                    if (verifyResponse.success) {
                        // Update login attempt status
                        String suspiciousReasonForLog = suspiciousReason;
                        if (isTrustedDevice) {
                            suspiciousReasonForLog = "";
                        }
                        
                        String method = isTrustedDevice ? "Trusted Device (Security Questions)" : "Security Questions";
                        
                        apiService.logLoginAttempt(email, deviceFingerprint, deviceModel,
                            networkType, networkSSID, ipAddress, "Success", method, suspiciousReasonForLog);
                        
                        // Update user network
                        String networkToStore = networkSSID != null && !networkSSID.isEmpty() ? 
                            networkSSID : "Mobile";
                        apiService.updateUserNetwork(email, networkToStore);
                        
                        // Ask if user wants to trust this device
                        if (!isTrustedDevice) {
                            showTrustDeviceDialog();
                        } else {
                            proceedToDashboard();
                        }
                    } else {
                        Toast.makeText(this, "Verification failed: " + verifyResponse.message, Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void showTrustDeviceDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Trust This Device?");
        builder.setMessage("By trusting this device, it will be a safe place. You can take steps to make this device a trusted device.");
        
        builder.setPositiveButton("Trust Device", (dialog, which) -> {
            Toast.makeText(this, "Adding device...", Toast.LENGTH_SHORT).show();
            new Thread(() -> {
                ApiService.ApiResponse response = apiService.addTrustedDevice(email, deviceFingerprint, deviceModel, deviceModel);
                runOnUiThread(() -> {
                    if (response.success) {
                        Toast.makeText(this, "Device added to trusted devices!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to add trusted device: " + response.message, Toast.LENGTH_LONG).show();
                    }
                    proceedToDashboard();
                });
            }).start();
        });
        
        builder.setNegativeButton("Not now", (dialog, which) -> {
            proceedToDashboard();
        });
        
        builder.setCancelable(false);
        builder.show();
    }

    private void proceedToDashboard() {
        saveLoggedEmail(email);
        Intent intent = new Intent(SecurityQuestionsActivity.this, DashboardActivity.class);
        startActivity(intent);
        finish();
    }

    private void saveLoggedEmail(String email) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("loggedEmail", email);
        editor.apply();
    }
}

