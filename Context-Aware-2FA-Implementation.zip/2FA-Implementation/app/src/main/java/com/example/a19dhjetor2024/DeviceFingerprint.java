package com.example.a19dhjetor2024;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DeviceFingerprint {
    
    public static String generateFingerprint(Context context) {
        StringBuilder fingerprintData = new StringBuilder();
        
        // Android ID (most stable identifier)
        String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        fingerprintData.append(androidId != null ? androidId : "unknown");
        
        // Model
        fingerprintData.append(Build.MODEL);
        
        // Manufacturer
        fingerprintData.append(Build.MANUFACTURER);
        
        // Hardware Board
        fingerprintData.append(Build.BOARD);
        
        // Device (more stable than maxMemory)
        fingerprintData.append(Build.DEVICE);
        
        // Product
        fingerprintData.append(Build.PRODUCT);
        
        // Screen Resolution (stable)
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        fingerprintData.append(displayMetrics.widthPixels).append("x").append(displayMetrics.heightPixels);
        
        // Add Build.SERIAL for more consistency (if available)
        try {
            String serial = Build.getSerial();
            if (serial != null && !serial.equals("unknown") && !serial.equals(Build.UNKNOWN)) {
                fingerprintData.append(serial);
            }
        } catch (Exception e) {
            // Ignore if serial is not available
        }
        
        // Hash the combined data
        String fingerprint = sha256(fingerprintData.toString());
        android.util.Log.d("DeviceFingerprint", "Generated fingerprint: " + getShortFingerprint(fingerprint));
        return fingerprint;
    }
    
    private static String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return input; // Fallback to original string
        }
    }
    
    public static String getShortFingerprint(String fingerprint) {
        if (fingerprint != null && fingerprint.length() > 16) {
            return fingerprint.substring(0, 16) + "...";
        }
        return fingerprint;
    }
}

