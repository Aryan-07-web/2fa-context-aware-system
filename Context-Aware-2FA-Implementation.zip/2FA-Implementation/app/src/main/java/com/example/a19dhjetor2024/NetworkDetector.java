package com.example.a19dhjetor2024;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;

public class NetworkDetector {
    
    public static class NetworkInfo {
        public String type; // "WiFi" or "Mobile"
        public String ssid; // WiFi SSID or null for mobile
        public String ipAddress;
        
        public NetworkInfo() {
            this.type = "Unknown";
            this.ssid = null;
            this.ipAddress = null;
        }
    }
    
    public static NetworkInfo getNetworkInfo(Context context) {
        NetworkInfo networkInfo = new NetworkInfo();
        
        ConnectivityManager connectivityManager = 
            (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        
        if (connectivityManager != null) {
            android.net.NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
            
            if (activeNetwork != null && activeNetwork.isConnected()) {
                if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                    networkInfo.type = "WiFi";
                    
                    // Get WiFi SSID
                    WifiManager wifiManager = (WifiManager) context.getApplicationContext()
                        .getSystemService(Context.WIFI_SERVICE);
                    
                    if (wifiManager != null) {
                        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                        String ssid = wifiInfo.getSSID();
                        if (ssid != null && !ssid.isEmpty() && !ssid.equals("<unknown ssid>")) {
                            // Remove quotes if present
                            networkInfo.ssid = ssid.replace("\"", "");
                        }
                    }
                    
                    // Get IP address
                    networkInfo.ipAddress = getWifiIpAddress(context);
                    
                } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                    networkInfo.type = "Mobile";
                    networkInfo.ipAddress = getMobileIpAddress();
                }
            }
        }
        
        return networkInfo;
    }
    
    private static String getWifiIpAddress(Context context) {
        try {
            WifiManager wifiManager = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
            
            if (wifiManager != null) {
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                int ipAddress = wifiInfo.getIpAddress();
                
                return String.format("%d.%d.%d.%d",
                    (ipAddress & 0xff),
                    (ipAddress >> 8 & 0xff),
                    (ipAddress >> 16 & 0xff),
                    (ipAddress >> 24 & 0xff));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return "Unknown";
    }
    
    private static String getMobileIpAddress() {
        // For mobile data, we can't easily get the IP without additional permissions
        // Return a placeholder
        return "Mobile IP";
    }
}

