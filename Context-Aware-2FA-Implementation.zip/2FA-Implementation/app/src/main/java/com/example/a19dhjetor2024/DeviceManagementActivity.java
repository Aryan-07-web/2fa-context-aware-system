package com.example.a19dhjetor2024;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import android.widget.Toast;

public class DeviceManagementActivity extends AppCompatActivity {
    private LinearLayout trustedDevicesContainer;
    private Button addDeviceButton;
    private Button backButton;
    private ApiService apiService;
    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_device_management);

        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        email = sharedPreferences.getString("loggedEmail", null);

        if (email == null) {
            startActivity(new Intent(this, Login.class));
            finish();
            return;
        }

        apiService = new ApiService(this);

        trustedDevicesContainer = findViewById(R.id.trustedDevicesContainer);
        addDeviceButton = findViewById(R.id.addDeviceButton);
        backButton = findViewById(R.id.backButton);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        loadTrustedDevices();

        addDeviceButton.setOnClickListener(v -> showAddDeviceDialog());

        backButton.setOnClickListener(v -> finish());
    }

    private void loadTrustedDevices() {
        trustedDevicesContainer.removeAllViews();
        
        TextView loadingText = new TextView(this);
        loadingText.setText("Loading devices...");
        loadingText.setPadding(20, 20, 20, 20);
        trustedDevicesContainer.addView(loadingText);
        
        new Thread(() -> {
            ApiService.ApiResponse response = apiService.getTrustedDevices(email);
            runOnUiThread(() -> {
                trustedDevicesContainer.removeAllViews();
                
                if (!response.success || response.data == null || response.data.isEmpty()) {
                    TextView emptyText = new TextView(this);
                    emptyText.setText("No trusted devices");
                    emptyText.setPadding(20, 20, 20, 20);
                    trustedDevicesContainer.addView(emptyText);
                    return;
                }
                
                try {
                    JSONObject json = new JSONObject(response.data);
                    JSONArray devicesArray = json.getJSONArray("data");
                    
                    if (devicesArray.length() == 0) {
                        TextView emptyText = new TextView(this);
                        emptyText.setText("No trusted devices");
                        emptyText.setPadding(20, 20, 20, 20);
                        trustedDevicesContainer.addView(emptyText);
                        return;
                    }
                    
                    for (int i = 0; i < devicesArray.length(); i++) {
                        JSONObject device = devicesArray.getJSONObject(i);
                        View deviceCard = createDeviceCard(device);
                        trustedDevicesContainer.addView(deviceCard);
                    }
                } catch (Exception e) {
                    android.util.Log.e("DeviceManagement", "Error parsing devices: " + e.getMessage());
                    TextView errorText = new TextView(this);
                    errorText.setText("Error loading devices");
                    errorText.setPadding(20, 20, 20, 20);
                    trustedDevicesContainer.addView(errorText);
                }
            });
        }).start();
    }

    private View createDeviceCard(JSONObject device) {
        try {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(20, 20, 20, 20);
            card.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

            String deviceName = device.optString("device_name", "");
            String deviceModel = device.optString("device_model", "Unknown");
            String lastLogin = device.optString("last_login", "Never");
            String deviceFingerprint = device.optString("device_fingerprint", "");

            TextView deviceNameText = new TextView(this);
            deviceNameText.setText("Device: " + (!deviceName.isEmpty() ? deviceName : deviceModel));
            deviceNameText.setTextSize(16);
            card.addView(deviceNameText);

            TextView deviceModelText = new TextView(this);
            deviceModelText.setText("Model: " + deviceModel);
            deviceModelText.setTextSize(14);
            card.addView(deviceModelText);

            TextView lastLoginText = new TextView(this);
            lastLoginText.setText("Last Login: " + lastLogin);
            lastLoginText.setTextSize(12);
            card.addView(lastLoginText);

            Button removeButton = new Button(this);
            removeButton.setText("Remove Device");
            removeButton.setOnClickListener(v -> showRemoveDeviceDialog(deviceFingerprint));
            card.addView(removeButton);

            return card;
        } catch (Exception e) {
            android.util.Log.e("DeviceManagement", "Error creating device card: " + e.getMessage());
            return new TextView(this);
        }
    }

    private void showRemoveDeviceDialog(String deviceFingerprint) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Remove Device");
        builder.setMessage("Are you sure you want to remove this device from trusted devices?");
        builder.setPositiveButton("Remove", (dialog, which) -> {
            // Note: We need to add a removeTrustedDevice endpoint to the backend
            // For now, we'll just reload the list
            Toast.makeText(this, "Remove device functionality requires backend endpoint", Toast.LENGTH_SHORT).show();
            loadTrustedDevices();
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showAddDeviceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Trusted Device");
        builder.setMessage("To add a new trusted device, please login from that device and select 'Trust Device' when prompted.");
        builder.setPositiveButton("OK", null);
        builder.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTrustedDevices();
    }
}

