package com.example.a19dhjetor2024;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

public class ContextAwareAuth {
    private static final String TAG = "ContextAwareAuth";
    
    public static class AuthContext {
        public String deviceFingerprint;
        public DeviceIntegrityChecker.IntegrityResult integrityResult;
        public NetworkDetector.NetworkInfo networkInfo;
        public boolean isTrustedDevice;
        public boolean requiresOTP;
        public String suspiciousReason;
        
        public AuthContext() {
            this.isTrustedDevice = false;
            this.requiresOTP = false;
            this.suspiciousReason = "";
        }
    }
    
    public static AuthContext evaluateContext(Context context, String email, ApiService apiService) {
        AuthContext authContext = new AuthContext();
        
        // Generate device fingerprint
        authContext.deviceFingerprint = DeviceFingerprint.generateFingerprint(context);
        
        // Check device integrity
        authContext.integrityResult = DeviceIntegrityChecker.checkDeviceIntegrity(context);
        
        // Detect network
        authContext.networkInfo = NetworkDetector.getNetworkInfo(context);
        
        // Check if device is trusted via API
        ApiService.ApiResponse trustedResponse = apiService.isDeviceTrusted(email, authContext.deviceFingerprint);
        if (trustedResponse.success) {
            try {
                JSONObject trustedJson = new JSONObject(trustedResponse.data);
                authContext.isTrustedDevice = trustedJson.getBoolean("isTrusted");
            } catch (Exception e) {
                Log.e(TAG, "Error parsing trusted device response", e);
                authContext.isTrustedDevice = false;
            }
        } else {
            authContext.isTrustedDevice = false;
        }
        
        // Check if device is blocked via API
        ApiService.ApiResponse blockedResponse = apiService.isDeviceBlocked(email, authContext.deviceFingerprint);
        if (blockedResponse.success) {
            try {
                JSONObject blockedJson = new JSONObject(blockedResponse.data);
                if (blockedJson.getBoolean("isBlocked")) {
                    authContext.requiresOTP = true;
                    authContext.suspiciousReason = "Device is blocked";
                    return authContext;
                }
            } catch (Exception e) {
                Log.e(TAG, "Error parsing blocked device response", e);
            }
        }
        
        // If device is trusted and integrity is good, allow direct login
        // Trusted devices should bypass OTP regardless of network (network change is noted but not blocking)
        if (authContext.isTrustedDevice && !authContext.integrityResult.isSuspicious) {
            // Trusted device with good integrity - allow direct login
            authContext.requiresOTP = false;
            
            // Check network mismatch for logging purposes (but don't block)
            ApiService.ApiResponse networkResponse = apiService.getLastNetwork(email);
            String lastNetwork = null;
            if (networkResponse.success) {
                try {
                    JSONObject networkJson = new JSONObject(networkResponse.data);
                    if (!networkJson.isNull("networkSSID")) {
                        lastNetwork = networkJson.getString("networkSSID");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing network response", e);
                }
            }
            
            if (lastNetwork != null && !lastNetwork.isEmpty()) {
                if (authContext.networkInfo.type.equals("WiFi") && 
                    authContext.networkInfo.ssid != null && 
                    !lastNetwork.equals(authContext.networkInfo.ssid)) {
                    // Network changed but device is trusted - note it but allow
                    authContext.suspiciousReason = "Network changed (trusted device)";
                } else {
                    authContext.suspiciousReason = ""; // No suspicious reason for trusted device
                }
            } else {
                authContext.suspiciousReason = ""; // No suspicious reason for trusted device
            }
            
            return authContext;
        }
        
        // Determine if OTP is required (for non-trusted devices or suspicious integrity)
        authContext.requiresOTP = true;
        
        // Build suspicious reason - only for non-trusted devices or suspicious integrity
        StringBuilder reason = new StringBuilder();
        
        // Only mark as suspicious if it's a new device (not trusted)
        if (!authContext.isTrustedDevice) {
            reason.append("New device detected. ");
        }
        
        // Add integrity issues if present
        if (authContext.integrityResult.isSuspicious) {
            if (authContext.integrityResult.isRooted) {
                reason.append("Device is rooted. ");
            }
            if (authContext.integrityResult.isEmulator) {
                reason.append("Emulator detected. ");
            }
            if (authContext.integrityResult.isUsbDebuggingOn) {
                reason.append("USB debugging enabled. ");
            }
            if (authContext.integrityResult.isDeveloperModeOn) {
                reason.append("Developer mode enabled. ");
            }
        }
        
        // Check network mismatch (only for non-trusted devices)
        if (!authContext.isTrustedDevice) {
            ApiService.ApiResponse networkResponse = apiService.getLastNetwork(email);
            String lastNetwork = null;
            if (networkResponse.success) {
                try {
                    JSONObject networkJson = new JSONObject(networkResponse.data);
                    if (!networkJson.isNull("networkSSID")) {
                        lastNetwork = networkJson.getString("networkSSID");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing network response", e);
                }
            }
            
            if (lastNetwork != null && !lastNetwork.isEmpty()) {
                if (authContext.networkInfo.type.equals("WiFi") && 
                    authContext.networkInfo.ssid != null && 
                    !lastNetwork.equals(authContext.networkInfo.ssid)) {
                    reason.append("Unusual network detected. ");
                }
            }
        }
        
        authContext.suspiciousReason = reason.toString().trim();
        if (authContext.suspiciousReason.isEmpty() && !authContext.isTrustedDevice) {
            authContext.suspiciousReason = "Additional verification required";
        }
        
        return authContext;
    }
}

