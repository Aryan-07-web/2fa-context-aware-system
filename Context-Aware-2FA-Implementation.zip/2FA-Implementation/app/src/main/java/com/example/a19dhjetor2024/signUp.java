package com.example.a19dhjetor2024;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.regex.Pattern;

public class signUp extends AppCompatActivity {

    private EditText editEmail;
    private EditText editName;
    private EditText editPassword;
    private EditText editConfirm;
    private Button signUp;
    private TextView logIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_up);

        editEmail = findViewById(R.id.email);
        editName = findViewById(R.id.name);
        editPassword = findViewById(R.id.password);
        editConfirm = findViewById(R.id.confirmPassword);
        signUp = findViewById(R.id.signUp);
        logIn = findViewById(R.id.logIn);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        signUp.setOnClickListener(view -> handleSignUp());

        logIn.setOnClickListener(view -> {
            Intent intent = new Intent(signUp.this, Login.class);
            startActivity(intent);
        });
    }

    private void handleSignUp() {
        String email = this.editEmail.getText().toString().trim();
        String name = this.editName.getText().toString().trim();
        String password = this.editPassword.getText().toString();
        String confirmPassword = this.editConfirm.getText().toString();

        String validateM = validateMessage(email, name, password, confirmPassword);
        if (validateM.isEmpty()) {
            // Navigate to security questions collection
            Intent intent = new Intent(signUp.this, SecurityQuestionsActivity.class);
            intent.putExtra("email", email);
            intent.putExtra("name", name);
            intent.putExtra("password", password);
            intent.putExtra("isRegistration", true);
            startActivity(intent);
        } else {
            Toast.makeText(this, validateM, Toast.LENGTH_LONG).show();
        }
    }

    private String validateMessage(String email, String name, String password, String confirmPassword) {
        if (name.isEmpty() || name.trim().isEmpty()) {
            return "Name cannot be empty";
        }
        if (email.isEmpty() || email.trim().isEmpty()) {
            return "Email cannot be empty";
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return "Please enter a valid email address";
        }
        
        // More lenient password validation - at least 6 characters
        if (password.isEmpty()) {
            return "Password cannot be empty";
        }
        if (password.length() < 6) {
            return "Password must be at least 6 characters long";
        }
        
        if (!confirmPassword.equals(password)) {
            return "Passwords do not match";
        }

        return "";
    }

}