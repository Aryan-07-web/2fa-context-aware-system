package com.example.a19dhjetor2024;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Login extends AppCompatActivity {
    private EditText editEmail;
    private EditText editPassword;
    private Button logIn;
    private TextView signUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(com.example.a19dhjetor2024.R.layout.activity_login);

        editEmail = findViewById(R.id.email);
        editPassword = findViewById(R.id.password);
        logIn = findViewById(R.id.logIn);
        signUp = findViewById(R.id.signUp);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        logIn.setOnClickListener(view -> handleLogIn());

        signUp.setOnClickListener(view -> {
            Intent intent = new Intent(Login.this, signUp.class);
            startActivity(intent);
        });
    }

    private void handleLogIn() {
        String email = this.editEmail.getText().toString().trim();
        String password = this.editPassword.getText().toString();

        if (email.isEmpty()) {
            Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (password.isEmpty()) {
            Toast.makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show loading
        Toast.makeText(this, "Logging in...", Toast.LENGTH_SHORT).show();
        
        // Perform login on background thread
        new Thread(() -> {
            ApiService apiService = new ApiService(this);
            
            // Validate credentials with backend first (this will tell us if user exists and is verified)
            ApiService.ApiResponse loginResponse = apiService.login(email, password);
            if (!loginResponse.success) {
                // Login failed - could be wrong credentials, user doesn't exist, or not verified
                runOnUiThread(() -> {
                    Toast.makeText(this, loginResponse.message, Toast.LENGTH_LONG).show();
                });
                return;
            }

            // Perform context-aware authentication (using API)
            ContextAwareAuth.AuthContext authContext = ContextAwareAuth.evaluateContext(this, email, apiService);
            
            // Debug: Log device fingerprint and trusted status
            android.util.Log.d("Login", "Device Fingerprint: " + DeviceFingerprint.getShortFingerprint(authContext.deviceFingerprint));
            android.util.Log.d("Login", "Is Trusted Device: " + authContext.isTrustedDevice);
            android.util.Log.d("Login", "Requires OTP: " + authContext.requiresOTP);
            
            // Check if device is blocked first
            ApiService.ApiResponse blockedResponse = apiService.isDeviceBlocked(email, authContext.deviceFingerprint);
            if (blockedResponse.success) {
                try {
                    org.json.JSONObject blockedJson = new org.json.JSONObject(blockedResponse.data);
                    if (blockedJson.getBoolean("isBlocked")) {
                        runOnUiThread(() -> {
                            showBlockedDeviceDialog();
                        });
                        return;
                    }
                } catch (Exception e) {
                    // Continue if error parsing
                }
            }
            
            String deviceModel = android.os.Build.MODEL;
            
            // If device is trusted and context is normal, skip security questions and go directly to dashboard
            if (authContext.isTrustedDevice && !authContext.requiresOTP) {
                // Direct login - trusted device
                saveLoggedEmail(email);
                String networkToStore = authContext.networkInfo.ssid != null ? 
                    authContext.networkInfo.ssid : "Mobile";
                apiService.updateUserNetwork(email, networkToStore);
                
                // Update last login for trusted device
                apiService.addTrustedDevice(email, authContext.deviceFingerprint, deviceModel, deviceModel);
                
                // Log successful login attempt (NOT suspicious - trusted device)
                String suspiciousReasonForLog = authContext.suspiciousReason != null && 
                    !authContext.suspiciousReason.isEmpty() ? authContext.suspiciousReason : "";
                
                apiService.logLoginAttempt(email, authContext.deviceFingerprint, deviceModel,
                    authContext.networkInfo.type, authContext.networkInfo.ssid, 
                    authContext.networkInfo.ipAddress, "Success", "Trusted Device", suspiciousReasonForLog);
                
                runOnUiThread(() -> {
                    Toast.makeText(this, "Welcome back! Trusted device detected.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Login.this, DashboardActivity.class);
                    startActivity(intent);
                    finish();
                });
                return;
            } else {
                // Require security questions (either new device or trusted device with suspicious integrity/network)
                String status = "Pending";
                String method = authContext.isTrustedDevice ? "Trusted Device (Security Questions Required)" : "Security Questions";
                
                // Only mark as suspicious if it's NOT a trusted device
                String suspiciousReasonForLog = authContext.suspiciousReason;
                if (authContext.isTrustedDevice) {
                    suspiciousReasonForLog = authContext.suspiciousReason != null && 
                        !authContext.suspiciousReason.isEmpty() ? 
                        authContext.suspiciousReason : "Additional verification required";
                }
                
                // Log login attempt
                apiService.logLoginAttempt(email, authContext.deviceFingerprint, deviceModel,
                    authContext.networkInfo.type, authContext.networkInfo.ssid, 
                    authContext.networkInfo.ipAddress, status, method, suspiciousReasonForLog);
                
                // Build explanation message for why security questions are required
                final String explanationMessage = buildSecurityQuestionExplanation(authContext);
                
                runOnUiThread(() -> {
                    // Show explanation dialog before asking for security questions
                    showSecurityQuestionExplanationDialog(explanationMessage, () -> {
                        saveLoggedEmail(email);
                        
                        Intent intent = new Intent(Login.this, SecurityQuestionsActivity.class);
                        intent.putExtra("email", email);
                        intent.putExtra("isRegistration", false);
                        intent.putExtra("deviceFingerprint", authContext.deviceFingerprint);
                        intent.putExtra("deviceModel", deviceModel);
                        intent.putExtra("networkType", authContext.networkInfo.type);
                        intent.putExtra("networkSSID", authContext.networkInfo.ssid);
                        intent.putExtra("ipAddress", authContext.networkInfo.ipAddress);
                        intent.putExtra("suspiciousReason", authContext.suspiciousReason);
                        intent.putExtra("isTrustedDevice", authContext.isTrustedDevice);
                        startActivity(intent);
                    });
                });
            }
        }).start();
    }
    
    private void showBlockedDeviceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Login Blocked");
        builder.setMessage("This device is blocked from login. Please contact support.");
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        builder.setCancelable(false);
        builder.show();
    }
    
    private String buildSecurityQuestionExplanation(ContextAwareAuth.AuthContext authContext) {
        StringBuilder explanation = new StringBuilder();
        
        if (authContext.isTrustedDevice) {
            explanation.append("This device is trusted, but additional verification is required due to:\n\n");
        } else {
            explanation.append("Additional verification is required because:\n\n");
        }
        
        // Check device integrity issues
        if (authContext.integrityResult.isSuspicious) {
            if (authContext.integrityResult.isRooted) {
                explanation.append("• Device is rooted\n");
            }
            if (authContext.integrityResult.isEmulator) {
                explanation.append("• Running on emulator\n");
            }
            if (authContext.integrityResult.isUsbDebuggingOn) {
                explanation.append("• USB debugging is enabled\n");
            }
            if (authContext.integrityResult.isDeveloperModeOn) {
                explanation.append("• Developer mode is enabled\n");
            }
        }
        
        // Check network changes
        if (authContext.suspiciousReason != null && authContext.suspiciousReason.contains("Network")) {
            explanation.append("• Network has changed\n");
        }
        
        // If no specific reason, provide generic message
        if (explanation.length() == (authContext.isTrustedDevice ? 
            "This device is trusted, but additional verification is required due to:\n\n".length() :
            "Additional verification is required because:\n\n".length())) {
            if (authContext.isTrustedDevice) {
                explanation.append("• Security policy requires periodic verification\n");
            } else {
                explanation.append("• This is a new device\n");
            }
        }
        
        explanation.append("\nPlease answer your security questions to continue.");
        
        return explanation.toString();
    }
    
    private void showSecurityQuestionExplanationDialog(String message, Runnable onContinue) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Security Verification Required");
        builder.setMessage(message);
        builder.setPositiveButton("Continue", (dialog, which) -> {
            dialog.dismiss();
            onContinue.run();
        });
        builder.setCancelable(false);
        builder.show();
    }

    private void saveLoggedEmail(String email) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("loggedEmail", email);
        editor.apply();
    }

}
