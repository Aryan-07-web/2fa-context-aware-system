package com.example.a19dhjetor2024;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * API Service for backend server communication
 * This class handles all HTTP requests to the backend server
 * 
 * TODO: Replace BASE_URL with your VM server URL
 * Example: "https://your-server.com/api" or "http://your-vm-ip:3000/api"
 */
public class ApiService {
    private static final String TAG = "ApiService";
    
    // VM Server Configuration
    // TODO: Update port if your backend runs on a different port
    private static final String BASE_URL = "http://192.168.2.243:3000/api";
    
    private Context context;
    
    public ApiService(Context context) {
        this.context = context;
    }
    
    /**
     * Register a new user
     */
    public ApiResponse register(String name, String email, String password) {
        try {
            JSONObject json = new JSONObject();
            json.put("name", name);
            json.put("email", email);
            json.put("password", password);
            
            return makeRequest("POST", "/auth/register", json.toString());
        } catch (Exception e) {
            Log.e(TAG, "Error in register", e);
            return new ApiResponse(false, "Registration failed: " + e.getMessage(), null);
        }
    }
    
    /**
     * Login user
     */
    public ApiResponse login(String email, String password) {
        try {
            JSONObject json = new JSONObject();
            json.put("email", email);
            json.put("password", password);
            
            return makeRequest("POST", "/auth/login", json.toString());
        } catch (Exception e) {
            Log.e(TAG, "Error in login", e);
            return new ApiResponse(false, "Login failed: " + e.getMessage(), null);
        }
    }
    
    /**
     * Register with security questions
     */
    public ApiResponse registerWithQuestions(String name, String email, String password, org.json.JSONArray securityQuestions) {
        try {
            JSONObject json = new JSONObject();
            json.put("name", name);
            json.put("email", email);
            json.put("password", password);
            json.put("securityQuestions", securityQuestions);
            
            String requestBody = json.toString();
            Log.d(TAG, "Register request body: " + requestBody);
            Log.d(TAG, "Security questions count: " + securityQuestions.length());
            
            return makeRequest("POST", "/auth/register", requestBody);
        } catch (Exception e) {
            Log.e(TAG, "Error in registerWithQuestions", e);
            return new ApiResponse(false, "Registration failed: " + e.getMessage(), null);
        }
    }
    
    /**
     * Get security questions for user
     */
    public ApiResponse getSecurityQuestions(String email) {
        try {
            return makeRequest("GET", "/auth/security-questions?email=" + email, null);
        } catch (Exception e) {
            Log.e(TAG, "Error in getSecurityQuestions", e);
            return new ApiResponse(false, "Failed to get security questions: " + e.getMessage(), null);
        }
    }
    
    /**
     * Verify security questions
     */
    public ApiResponse verifySecurityQuestions(String email, org.json.JSONArray answers) {
        try {
            JSONObject json = new JSONObject();
            json.put("email", email);
            json.put("answers", answers);
            
            return makeRequest("POST", "/auth/verify-security-questions", json.toString());
        } catch (Exception e) {
            Log.e(TAG, "Error in verifySecurityQuestions", e);
            return new ApiResponse(false, "Verification failed: " + e.getMessage(), null);
        }
    }
    
    /**
     * Evaluate context for authentication
     */
    public ApiResponse evaluateContext(String email, String deviceFingerprint, 
                                       String deviceModel, String networkType, 
                                       String networkSSID, String ipAddress) {
        try {
            JSONObject json = new JSONObject();
            json.put("email", email);
            json.put("deviceFingerprint", deviceFingerprint);
            json.put("deviceModel", deviceModel);
            json.put("networkType", networkType);
            json.put("networkSSID", networkSSID);
            json.put("ipAddress", ipAddress);
            
            return makeRequest("POST", "/security/evaluate-context", json.toString());
        } catch (Exception e) {
            Log.e(TAG, "Error in evaluateContext", e);
            return new ApiResponse(false, "Context evaluation failed: " + e.getMessage(), null);
        }
    }
    
    /**
     * Add trusted device
     */
    public ApiResponse addTrustedDevice(String email, String deviceFingerprint, 
                                       String deviceName, String deviceModel) {
        try {
            JSONObject json = new JSONObject();
            json.put("email", email);
            json.put("deviceFingerprint", deviceFingerprint);
            json.put("deviceName", deviceName);
            json.put("deviceModel", deviceModel);
            
            return makeRequest("POST", "/devices/trust", json.toString());
        } catch (Exception e) {
            Log.e(TAG, "Error in addTrustedDevice", e);
            return new ApiResponse(false, "Failed to add trusted device: " + e.getMessage(), null);
        }
    }
    
    /**
     * Log login attempt
     */
    public ApiResponse logLoginAttempt(String email, String deviceFingerprint, 
                                      String deviceModel, String networkType, 
                                      String networkSSID, String ipAddress, 
                                      String status, String method, String suspiciousReason) {
        try {
            JSONObject json = new JSONObject();
            json.put("email", email);
            json.put("deviceFingerprint", deviceFingerprint);
            json.put("deviceModel", deviceModel);
            json.put("networkType", networkType);
            json.put("networkSSID", networkSSID);
            json.put("ipAddress", ipAddress);
            json.put("status", status);
            json.put("method", method);
            json.put("suspiciousReason", suspiciousReason);
            
            return makeRequest("POST", "/security/login-attempts", json.toString());
        } catch (Exception e) {
            Log.e(TAG, "Error in logLoginAttempt", e);
            return new ApiResponse(false, "Failed to log attempt: " + e.getMessage(), null);
        }
    }
    
    /**
     * Get login attempts
     */
    public ApiResponse getLoginAttempts(String email) {
        try {
            return makeRequest("GET", "/security/login-attempts?email=" + email, null);
        } catch (Exception e) {
            Log.e(TAG, "Error in getLoginAttempts", e);
            return new ApiResponse(false, "Failed to get login attempts: " + e.getMessage(), null);
        }
    }
    
    /**
     * Block device
     */
    public ApiResponse blockDevice(String email, String deviceFingerprint) {
        try {
            JSONObject json = new JSONObject();
            json.put("email", email);
            json.put("deviceFingerprint", deviceFingerprint);
            
            return makeRequest("POST", "/security/block-device", json.toString());
        } catch (Exception e) {
            Log.e(TAG, "Error in blockDevice", e);
            return new ApiResponse(false, "Failed to block device: " + e.getMessage(), null);
        }
    }
    
    /**
     * Check if user exists
     */
    public ApiResponse checkUserExists(String email) {
        try {
            return makeRequest("GET", "/auth/user-exists?email=" + email, null);
        } catch (Exception e) {
            Log.e(TAG, "Error in checkUserExists", e);
            return new ApiResponse(false, "Failed to check user: " + e.getMessage(), null);
        }
    }
    
    /**
     * Check if account is verified
     */
    public ApiResponse checkAccountVerified(String email) {
        try {
            return makeRequest("GET", "/auth/account-verified?email=" + email, null);
        } catch (Exception e) {
            Log.e(TAG, "Error in checkAccountVerified", e);
            return new ApiResponse(false, "Failed to check verification: " + e.getMessage(), null);
        }
    }
    
    
    /**
     * Get trusted devices list
     */
    public ApiResponse getTrustedDevices(String email) {
        try {
            return makeRequest("GET", "/devices/trust?email=" + email, null);
        } catch (Exception e) {
            Log.e(TAG, "Error in getTrustedDevices", e);
            return new ApiResponse(false, "Failed to get trusted devices: " + e.getMessage(), null);
        }
    }
    
    /**
     * Check if device is trusted
     */
    public ApiResponse isDeviceTrusted(String email, String deviceFingerprint) {
        try {
            return makeRequest("GET", "/devices/trust-check?email=" + email + "&deviceFingerprint=" + deviceFingerprint, null);
        } catch (Exception e) {
            Log.e(TAG, "Error in isDeviceTrusted", e);
            return new ApiResponse(false, "Failed to check device: " + e.getMessage(), null);
        }
    }
    
    /**
     * Check if device is blocked
     */
    public ApiResponse isDeviceBlocked(String email, String deviceFingerprint) {
        try {
            return makeRequest("GET", "/security/block-check?email=" + email + "&deviceFingerprint=" + deviceFingerprint, null);
        } catch (Exception e) {
            Log.e(TAG, "Error in isDeviceBlocked", e);
            return new ApiResponse(false, "Failed to check block status: " + e.getMessage(), null);
        }
    }
    
    /**
     * Get last network for user
     */
    public ApiResponse getLastNetwork(String email) {
        try {
            return makeRequest("GET", "/security/last-network?email=" + email, null);
        } catch (Exception e) {
            Log.e(TAG, "Error in getLastNetwork", e);
            return new ApiResponse(false, "Failed to get network: " + e.getMessage(), null);
        }
    }
    
    /**
     * Update user network
     */
    public ApiResponse updateUserNetwork(String email, String networkSSID) {
        try {
            JSONObject json = new JSONObject();
            json.put("email", email);
            json.put("networkSSID", networkSSID);
            
            return makeRequest("POST", "/security/update-network", json.toString());
        } catch (Exception e) {
            Log.e(TAG, "Error in updateUserNetwork", e);
            return new ApiResponse(false, "Failed to update network: " + e.getMessage(), null);
        }
    }
    
    /**
     * Make HTTP request to backend
     */
    private ApiResponse makeRequest(String method, String endpoint, String jsonBody) {
        HttpURLConnection connection = null;
        String fullUrl = BASE_URL + endpoint;
        
        try {
            Log.d(TAG, "Making " + method + " request to: " + fullUrl);
            URL url = new URL(fullUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(method);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            connection.setConnectTimeout(15000); // Increased timeout
            connection.setReadTimeout(15000);
            
            if (jsonBody != null && (method.equals("POST") || method.equals("PUT"))) {
                connection.setDoOutput(true);
                Log.d(TAG, "Request body: " + jsonBody);
                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = jsonBody.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }
            }
            
            int responseCode = connection.getResponseCode();
            Log.d(TAG, "Response code: " + responseCode);
            
            BufferedReader reader;
            if (responseCode >= 200 && responseCode < 300) {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            } else {
                InputStream errorStream = connection.getErrorStream();
                if (errorStream != null) {
                    reader = new BufferedReader(new InputStreamReader(errorStream));
                } else {
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                }
            }
            
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            
            String responseBody = response.toString();
            Log.d(TAG, "Response body: " + responseBody);
            
            if (responseCode >= 200 && responseCode < 300) {
                return new ApiResponse(true, "Success", responseBody);
            } else {
                // Try to parse error message from JSON response
                String errorMessage = "Server error: " + responseCode;
                if (responseBody != null && !responseBody.isEmpty()) {
                    try {
                        JSONObject errorJson = new JSONObject(responseBody);
                        if (errorJson.has("message")) {
                            errorMessage = errorJson.getString("message");
                        } else if (errorJson.has("error")) {
                            errorMessage = errorJson.getString("error");
                        }
                    } catch (Exception e) {
                        // If parsing fails, use default message
                        Log.d(TAG, "Could not parse error response: " + e.getMessage());
                    }
                }
                return new ApiResponse(false, errorMessage, responseBody);
            }
            
        } catch (java.net.UnknownHostException e) {
            String errorMsg = "Cannot connect to server. Please check if the backend server is running at " + BASE_URL;
            Log.e(TAG, errorMsg, e);
            return new ApiResponse(false, errorMsg, null);
        } catch (java.net.ConnectException e) {
            String errorMsg = "Connection refused. Please check if the backend server is running at " + BASE_URL;
            Log.e(TAG, errorMsg, e);
            return new ApiResponse(false, errorMsg, null);
        } catch (java.net.SocketTimeoutException e) {
            String errorMsg = "Connection timeout. Server may be slow or unreachable.";
            Log.e(TAG, errorMsg, e);
            return new ApiResponse(false, errorMsg, null);
        } catch (java.io.IOException e) {
            String errorMsg = e.getMessage();
            if (errorMsg == null || errorMsg.isEmpty()) {
                errorMsg = "Network I/O error occurred";
            }
            Log.e(TAG, "Network I/O error: " + errorMsg, e);
            return new ApiResponse(false, "Network error: " + errorMsg, null);
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            if (errorMsg == null || errorMsg.isEmpty()) {
                errorMsg = e.getClass().getSimpleName() + " occurred";
            }
            Log.e(TAG, "Unexpected error: " + errorMsg, e);
            return new ApiResponse(false, "Error: " + errorMsg, null);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
    
    /**
     * Response class for API calls
     */
    public static class ApiResponse {
        public boolean success;
        public String message;
        public String data;
        
        public ApiResponse(boolean success, String message, String data) {
            this.success = success;
            this.message = message;
            this.data = data;
        }
    }
}

