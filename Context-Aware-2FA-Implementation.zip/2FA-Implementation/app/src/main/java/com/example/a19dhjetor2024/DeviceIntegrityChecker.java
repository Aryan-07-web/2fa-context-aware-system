package com.example.a19dhjetor2024;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;

import java.io.File;

public class DeviceIntegrityChecker {
    
    public static class IntegrityResult {
        public boolean isRooted;
        public boolean isEmulator;
        public boolean isUsbDebuggingOn;
        public boolean isDeveloperModeOn;
        public boolean isSuspicious;
        
        public IntegrityResult() {
            this.isRooted = false;
            this.isEmulator = false;
            this.isUsbDebuggingOn = false;
            this.isDeveloperModeOn = false;
            this.isSuspicious = false;
        }
    }
    
    public static IntegrityResult checkDeviceIntegrity(Context context) {
        IntegrityResult result = new IntegrityResult();
        
        // Check if device is rooted
        result.isRooted = isRooted();
        
        // Check if device is an emulator
        result.isEmulator = isEmulator();
        
        // Check USB debugging
        result.isUsbDebuggingOn = isUsbDebuggingEnabled(context);
        
        // Check developer mode
        result.isDeveloperModeOn = isDeveloperModeEnabled(context);
        
        // Mark as suspicious if any check fails
        result.isSuspicious = result.isRooted || result.isEmulator || 
                             result.isUsbDebuggingOn || result.isDeveloperModeOn;
        
        return result;
    }
    
    private static boolean isRooted() {
        // Check for common root binaries
        String[] rootPaths = {
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su"
        };
        
        for (String path : rootPaths) {
            if (new File(path).exists()) {
                return true;
            }
        }
        
        // Check for su command
        try {
            Process process = Runtime.getRuntime().exec("which su");
            java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.InputStreamReader(process.getInputStream()));
            String line = reader.readLine();
            reader.close();
            if (line != null && !line.isEmpty()) {
                return true;
            }
        } catch (Exception e) {
            // Ignore
        }
        
        return false;
    }
    
    private static boolean isEmulator() {
        return Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || "google_sdk".equals(Build.PRODUCT);
    }
    
    private static boolean isUsbDebuggingEnabled(Context context) {
        try {
            int adbEnabled = Settings.Global.getInt(
                context.getContentResolver(),
                Settings.Global.ADB_ENABLED, 0
            );
            return adbEnabled == 1;
        } catch (Exception e) {
            return false;
        }
    }
    
    private static boolean isDeveloperModeEnabled(Context context) {
        try {
            int developerMode = Settings.Global.getInt(
                context.getContentResolver(),
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0
            );
            return developerMode == 1;
        } catch (Exception e) {
            return false;
        }
    }
}

