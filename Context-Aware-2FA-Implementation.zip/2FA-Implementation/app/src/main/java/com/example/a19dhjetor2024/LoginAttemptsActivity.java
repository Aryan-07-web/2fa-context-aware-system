package com.example.a19dhjetor2024;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import android.widget.Toast;

public class LoginAttemptsActivity extends AppCompatActivity {
    private LinearLayout loginAttemptsContainer;
    private Button backButton;
    private ApiService apiService;
    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_attempts);

        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        email = sharedPreferences.getString("loggedEmail", null);

        if (email == null) {
            startActivity(new Intent(this, Login.class));
            finish();
            return;
        }

        apiService = new ApiService(this);

        loginAttemptsContainer = findViewById(R.id.loginAttemptsContainer);
        backButton = findViewById(R.id.backButton);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        loadLoginAttempts();

        backButton.setOnClickListener(v -> finish());
    }

    private void loadLoginAttempts() {
        loginAttemptsContainer.removeAllViews();
        
        TextView loadingText = new TextView(this);
        loadingText.setText("Loading login attempts...");
        loadingText.setPadding(20, 20, 20, 20);
        loginAttemptsContainer.addView(loadingText);
        
        new Thread(() -> {
            ApiService.ApiResponse response = apiService.getLoginAttempts(email);
            runOnUiThread(() -> {
                loginAttemptsContainer.removeAllViews();
                
                if (!response.success || response.data == null || response.data.isEmpty()) {
                    TextView emptyText = new TextView(this);
                    emptyText.setText("No login attempts found");
                    emptyText.setPadding(20, 20, 20, 20);
                    loginAttemptsContainer.addView(emptyText);
                    return;
                }
                
                try {
                    JSONObject json = new JSONObject(response.data);
                    JSONArray attemptsArray = json.getJSONArray("data");
                    
                    if (attemptsArray.length() == 0) {
                        TextView emptyText = new TextView(this);
                        emptyText.setText("No login attempts found");
                        emptyText.setPadding(20, 20, 20, 20);
                        loginAttemptsContainer.addView(emptyText);
                        return;
                    }
                    
                    for (int i = 0; i < attemptsArray.length(); i++) {
                        JSONObject attempt = attemptsArray.getJSONObject(i);
                        View attemptCard = createAttemptCard(attempt);
                        loginAttemptsContainer.addView(attemptCard);
                    }
                } catch (Exception e) {
                    android.util.Log.e("LoginAttempts", "Error parsing attempts: " + e.getMessage());
                    TextView errorText = new TextView(this);
                    errorText.setText("Error loading login attempts");
                    errorText.setPadding(20, 20, 20, 20);
                    loginAttemptsContainer.addView(errorText);
                }
            });
        }).start();
    }

    private View createAttemptCard(JSONObject attempt) {
        try {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(20, 20, 20, 20);
            card.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

            String timestamp = attempt.optString("timestamp", "Unknown");
            String ipAddress = attempt.optString("ip_address", "Unknown");
            String deviceModel = attempt.optString("device_model", "Unknown");
            String networkType = attempt.optString("network_type", "Unknown");
            String networkSSID = attempt.optString("network_ssid", "");
            String status = attempt.optString("status", "Unknown");
            String method = attempt.optString("method", "Unknown");
            String suspiciousReason = attempt.optString("suspicious_reason", "");
            String deviceFingerprint = attempt.optString("device_fingerprint", "");

            TextView timestampText = new TextView(this);
            timestampText.setText("Timestamp: " + timestamp);
            timestampText.setTextSize(14);
            card.addView(timestampText);

            TextView ipText = new TextView(this);
            ipText.setText("IP Address: " + ipAddress);
            ipText.setTextSize(12);
            card.addView(ipText);

            TextView deviceText = new TextView(this);
            deviceText.setText("Device: " + deviceModel);
            deviceText.setTextSize(12);
            card.addView(deviceText);

            TextView networkText = new TextView(this);
            String networkInfo = networkType;
            if (networkSSID != null && !networkSSID.isEmpty()) {
                networkInfo += " (" + networkSSID + ")";
            }
            networkText.setText("Network: " + networkInfo);
            networkText.setTextSize(12);
            card.addView(networkText);

            TextView statusText = new TextView(this);
            statusText.setText("Status: " + status);
            statusText.setTextSize(12);
            card.addView(statusText);

            TextView methodText = new TextView(this);
            methodText.setText("Method: " + method);
            methodText.setTextSize(12);
            card.addView(methodText);

            if (suspiciousReason != null && !suspiciousReason.isEmpty()) {
                TextView suspiciousText = new TextView(this);
                suspiciousText.setText("Reason: " + suspiciousReason);
                suspiciousText.setTextSize(12);
                suspiciousText.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                card.addView(suspiciousText);
            }

            Button blockButton = new Button(this);
            blockButton.setText("Block Device");
            blockButton.setOnClickListener(v -> showBlockDeviceDialog(deviceFingerprint));
            card.addView(blockButton);

            return card;
        } catch (Exception e) {
            android.util.Log.e("LoginAttempts", "Error creating attempt card: " + e.getMessage());
            return new TextView(this);
        }
    }

    private void showBlockDeviceDialog(String deviceFingerprint) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Block Device");
        builder.setMessage("Are you sure you want to block this device? It will not be able to login.");
        builder.setPositiveButton("Block", (dialog, which) -> {
            new Thread(() -> {
                ApiService.ApiResponse response = apiService.blockDevice(email, deviceFingerprint);
                runOnUiThread(() -> {
                    if (response.success) {
                        Toast.makeText(this, "Device blocked", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to block device: " + response.message, Toast.LENGTH_LONG).show();
                    }
                });
            }).start();
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}

