package com.example.a19dhjetor2024;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import org.mindrot.jbcrypt.BCrypt;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class DB extends SQLiteOpenHelper {
    private static final String DBNAME = "db";
    private static final int DB_VERSION = 2;

    public DB(@Nullable Context context) {
        super(context, DBNAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE User (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT, " +
                "fullName TEXT, " +
                "passwordHash TEXT, " +
                "salt TEXT, " +
                "verificationCode TEXT)");
        
        // Trusted Devices table
        db.execSQL("CREATE TABLE TrustedDevices (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT, " +
                "deviceFingerprint TEXT, " +
                "deviceName TEXT, " +
                "deviceModel TEXT, " +
                "lastLogin TEXT, " +
                "createdAt TEXT)");
        
        // Login Attempts table
        db.execSQL("CREATE TABLE LoginAttempts (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT, " +
                "deviceFingerprint TEXT, " +
                "deviceModel TEXT, " +
                "networkType TEXT, " +
                "networkSSID TEXT, " +
                "ipAddress TEXT, " +
                "status TEXT, " +
                "method TEXT, " +
                "suspiciousReason TEXT, " +
                "timestamp TEXT)");
        
        // User Networks table (to track last network per user)
        db.execSQL("CREATE TABLE UserNetworks (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT, " +
                "networkSSID TEXT, " +
                "lastUsed TEXT)");
        
        // Blocked Devices table
        db.execSQL("CREATE TABLE BlockedDevices (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT, " +
                "deviceFingerprint TEXT, " +
                "blockedAt TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Create new tables for version 2
            db.execSQL("CREATE TABLE IF NOT EXISTS TrustedDevices (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "email TEXT, " +
                    "deviceFingerprint TEXT, " +
                    "deviceName TEXT, " +
                    "deviceModel TEXT, " +
                    "lastLogin TEXT, " +
                    "createdAt TEXT)");
            
            db.execSQL("CREATE TABLE IF NOT EXISTS LoginAttempts (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "email TEXT, " +
                    "deviceFingerprint TEXT, " +
                    "deviceModel TEXT, " +
                    "networkType TEXT, " +
                    "networkSSID TEXT, " +
                    "ipAddress TEXT, " +
                    "status TEXT, " +
                    "method TEXT, " +
                    "suspiciousReason TEXT, " +
                    "timestamp TEXT)");
            
            db.execSQL("CREATE TABLE IF NOT EXISTS UserNetworks (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "email TEXT, " +
                    "networkSSID TEXT, " +
                    "lastUsed TEXT)");
            
            db.execSQL("CREATE TABLE IF NOT EXISTS BlockedDevices (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "email TEXT, " +
                    "deviceFingerprint TEXT, " +
                    "blockedAt TEXT)");
        }
    }

    public boolean signUp(String name, String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String salt = BCrypt.gensalt();
        String hashedPassword = BCrypt.hashpw(password, salt);
        String verificationCode = generateVerificationCode();

        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("fullName", name);
        contentValues.put("passwordHash", hashedPassword);
        contentValues.put("salt", salt);
        contentValues.put("verificationCode", verificationCode);

        long result = db.insert("User", null, contentValues);
        db.close();

        if (result != -1) {
            EmailSender emailSender = new EmailSender();
            try {
                emailSender.sendOTPEmail(email, "Verification Code", "Verification Code for Sign up: " + verificationCode);
                Log.d("DB", "Inserting user with email: " + email);
            } catch (Exception e) {
                Log.e("EmailError", "Failed to send OTP email", e);
            }
            return true;
        }
        return false;
    }

    public String generateVerificationCode() {
        Random random = new Random();
        return Integer.toString(random.nextInt(999999));
    }

    public String getVerificationCode(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String verificationCode = null;

        Cursor cursor = db.rawQuery(
                "SELECT verificationCode FROM User WHERE email = ?",
                new String[]{email}
        );

        if (cursor != null && cursor.moveToFirst()) {
            verificationCode = cursor.getString(cursor.getColumnIndexOrThrow("verificationCode"));
        }

        if (cursor != null) {
            cursor.close();
        }
        return verificationCode;
    }

    public boolean checkEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM User WHERE email=? and verificationCode = ?", new String[]{email, "0"});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public void validateTheUser(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            db.beginTransaction();
            db.execSQL("UPDATE User SET verificationCode = ? WHERE email=?", new Object[]{"0", email});
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e("DBError", "Error updating user verification", e);
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    public void logInUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        String verificationCode = generateVerificationCode();

        db.execSQL("UPDATE User SET verificationCode = ? WHERE email=?", new Object[]{verificationCode, email});
        EmailSender emailSender = new EmailSender();
        emailSender.sendOTPEmail(email, "Verification Code for Log in", verificationCode);
    }

    public boolean validateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT passwordHash, salt FROM User WHERE email=? and verificationCode = ?", new String[]{email, "0"});

        if (cursor.moveToFirst()) {
            String storedHash = cursor.getString(0);
            cursor.close();
            return BCrypt.checkpw(password, storedHash);
        }
        cursor.close();
        return false;
    }
    
    public boolean userExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM User WHERE email=?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
    
    public boolean isAccountVerified(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT verificationCode FROM User WHERE email=?", new String[]{email});
        if (cursor.moveToFirst()) {
            String verificationCode = cursor.getString(0);
            cursor.close();
            // Account is verified if verificationCode is "0"
            return verificationCode != null && verificationCode.equals("0");
        }
        cursor.close();
        return false;
    }
    
    // Trusted Devices Methods
    public boolean isDeviceTrusted(String email, String deviceFingerprint) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT * FROM TrustedDevices WHERE email=? AND deviceFingerprint=?",
            new String[]{email, deviceFingerprint}
        );
        boolean isTrusted = cursor.getCount() > 0;
        
        // Debug logging
        if (isTrusted) {
            Log.d("DB", "Device IS trusted for email: " + email);
        } else {
            Log.d("DB", "Device NOT trusted for email: " + email);
            // Check if any trusted devices exist for this user
            Cursor allDevices = db.rawQuery(
                "SELECT deviceFingerprint FROM TrustedDevices WHERE email=?",
                new String[]{email}
            );
            Log.d("DB", "Total trusted devices for user: " + allDevices.getCount());
            if (allDevices.moveToFirst()) {
                do {
                    String storedFingerprint = allDevices.getString(0);
                    Log.d("DB", "Stored fingerprint: " + DeviceFingerprint.getShortFingerprint(storedFingerprint));
                    Log.d("DB", "Current fingerprint: " + DeviceFingerprint.getShortFingerprint(deviceFingerprint));
                    Log.d("DB", "Match: " + storedFingerprint.equals(deviceFingerprint));
                } while (allDevices.moveToNext());
            }
            allDevices.close();
        }
        
        cursor.close();
        return isTrusted;
    }
    
    public void addTrustedDevice(String email, String deviceFingerprint, String deviceName, String deviceModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        // Check if device already exists
        if (isDeviceTrusted(email, deviceFingerprint)) {
            // Update last login
            updateTrustedDeviceLastLogin(email, deviceFingerprint);
            return;
        }
        
        // Check if user has more than 3 trusted devices
        int deviceCount = getTrustedDeviceCount(email);
        if (deviceCount >= 3) {
            // Remove least recently used device
            removeLeastRecentlyUsedDevice(email);
        }
        
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("deviceFingerprint", deviceFingerprint);
        values.put("deviceName", deviceName);
        values.put("deviceModel", deviceModel);
        values.put("lastLogin", getCurrentTimestamp());
        values.put("createdAt", getCurrentTimestamp());
        
        long result = db.insert("TrustedDevices", null, values);
        Log.d("DB", "Inserted trusted device. Result: " + result);
        
        // Verify it was saved
        boolean verified = isDeviceTrusted(email, deviceFingerprint);
        Log.d("DB", "Verified trusted device after insert: " + verified);
        
        db.close();
    }
    
    private int getTrustedDeviceCount(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT COUNT(*) FROM TrustedDevices WHERE email=?",
            new String[]{email}
        );
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }
    
    private void removeLeastRecentlyUsedDevice(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(
            "DELETE FROM TrustedDevices WHERE id = (" +
            "SELECT id FROM TrustedDevices WHERE email=? " +
            "ORDER BY lastLogin ASC LIMIT 1)",
            new String[]{email}
        );
        db.close();
    }
    
    private void updateTrustedDeviceLastLogin(String email, String deviceFingerprint) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("lastLogin", getCurrentTimestamp());
        db.update("TrustedDevices", values, "email=? AND deviceFingerprint=?", 
            new String[]{email, deviceFingerprint});
        db.close();
    }
    
    public List<TrustedDevice> getTrustedDevices(String email) {
        List<TrustedDevice> devices = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT * FROM TrustedDevices WHERE email=? ORDER BY lastLogin DESC",
            new String[]{email}
        );
        
        while (cursor.moveToNext()) {
            TrustedDevice device = new TrustedDevice();
            device.id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            device.email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
            device.deviceFingerprint = cursor.getString(cursor.getColumnIndexOrThrow("deviceFingerprint"));
            device.deviceName = cursor.getString(cursor.getColumnIndexOrThrow("deviceName"));
            device.deviceModel = cursor.getString(cursor.getColumnIndexOrThrow("deviceModel"));
            device.lastLogin = cursor.getString(cursor.getColumnIndexOrThrow("lastLogin"));
            device.createdAt = cursor.getString(cursor.getColumnIndexOrThrow("createdAt"));
            devices.add(device);
        }
        cursor.close();
        return devices;
    }
    
    public void removeTrustedDevice(String email, String deviceFingerprint) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("TrustedDevices", "email=? AND deviceFingerprint=?", 
            new String[]{email, deviceFingerprint});
        db.close();
    }
    
    // Login Attempts Methods
    public void logLoginAttempt(String email, String deviceFingerprint, String deviceModel,
                               String networkType, String networkSSID, String ipAddress,
                               String status, String method, String suspiciousReason) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("deviceFingerprint", deviceFingerprint);
        values.put("deviceModel", deviceModel);
        values.put("networkType", networkType);
        values.put("networkSSID", networkSSID);
        values.put("ipAddress", ipAddress);
        values.put("status", status);
        values.put("method", method);
        values.put("suspiciousReason", suspiciousReason);
        values.put("timestamp", getCurrentTimestamp());
        
        db.insert("LoginAttempts", null, values);
        db.close();
    }
    
    public List<LoginAttempt> getLoginAttempts(String email) {
        List<LoginAttempt> attempts = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT * FROM LoginAttempts WHERE email=? ORDER BY timestamp DESC LIMIT 50",
            new String[]{email}
        );
        
        while (cursor.moveToNext()) {
            LoginAttempt attempt = new LoginAttempt();
            attempt.id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            attempt.email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
            attempt.deviceFingerprint = cursor.getString(cursor.getColumnIndexOrThrow("deviceFingerprint"));
            attempt.deviceModel = cursor.getString(cursor.getColumnIndexOrThrow("deviceModel"));
            attempt.networkType = cursor.getString(cursor.getColumnIndexOrThrow("networkType"));
            attempt.networkSSID = cursor.getString(cursor.getColumnIndexOrThrow("networkSSID"));
            attempt.ipAddress = cursor.getString(cursor.getColumnIndexOrThrow("ipAddress"));
            attempt.status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
            attempt.method = cursor.getString(cursor.getColumnIndexOrThrow("method"));
            attempt.suspiciousReason = cursor.getString(cursor.getColumnIndexOrThrow("suspiciousReason"));
            attempt.timestamp = cursor.getString(cursor.getColumnIndexOrThrow("timestamp"));
            attempts.add(attempt);
        }
        cursor.close();
        return attempts;
    }
    
    // Network Methods
    public void updateUserNetwork(String email, String networkSSID) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        if (networkSSID == null || networkSSID.isEmpty()) {
            // For mobile networks, store "Mobile" as the network type
            networkSSID = "Mobile";
        }
        
        // Check if network exists for user
        Cursor cursor = db.rawQuery(
            "SELECT * FROM UserNetworks WHERE email=? AND networkSSID=?",
            new String[]{email, networkSSID}
        );
        
        if (cursor.getCount() > 0) {
            // Update last used
            ContentValues values = new ContentValues();
            values.put("lastUsed", getCurrentTimestamp());
            db.update("UserNetworks", values, "email=? AND networkSSID=?", 
                new String[]{email, networkSSID});
        } else {
            // Insert new network
            ContentValues values = new ContentValues();
            values.put("email", email);
            values.put("networkSSID", networkSSID);
            values.put("lastUsed", getCurrentTimestamp());
            db.insert("UserNetworks", null, values);
        }
        
        cursor.close();
        db.close();
    }
    
    public String getLastNetworkForUser(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT networkSSID FROM UserNetworks WHERE email=? ORDER BY lastUsed DESC LIMIT 1",
            new String[]{email}
        );
        
        String networkSSID = null;
        if (cursor.moveToFirst()) {
            networkSSID = cursor.getString(0);
        }
        cursor.close();
        return networkSSID;
    }
    
    // Blocked Devices Methods
    public boolean isDeviceBlocked(String email, String deviceFingerprint) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT * FROM BlockedDevices WHERE email=? AND deviceFingerprint=?",
            new String[]{email, deviceFingerprint}
        );
        boolean isBlocked = cursor.getCount() > 0;
        cursor.close();
        return isBlocked;
    }
    
    public void blockDevice(String email, String deviceFingerprint) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        // Check if already blocked
        if (!isDeviceBlocked(email, deviceFingerprint)) {
            ContentValues values = new ContentValues();
            values.put("email", email);
            values.put("deviceFingerprint", deviceFingerprint);
            values.put("blockedAt", getCurrentTimestamp());
            db.insert("BlockedDevices", null, values);
        }
        db.close();
    }
    
    public void unblockDevice(String email, String deviceFingerprint) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("BlockedDevices", "email=? AND deviceFingerprint=?", 
            new String[]{email, deviceFingerprint});
        db.close();
    }
    
    // Helper Methods
    private String getCurrentTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }
    
    // Data Classes
    public static class TrustedDevice {
        public int id;
        public String email;
        public String deviceFingerprint;
        public String deviceName;
        public String deviceModel;
        public String lastLogin;
        public String createdAt;
    }
    
    public static class LoginAttempt {
        public int id;
        public String email;
        public String deviceFingerprint;
        public String deviceModel;
        public String networkType;
        public String networkSSID;
        public String ipAddress;
        public String status;
        public String method;
        public String suspiciousReason;
        public String timestamp;
    }
}
