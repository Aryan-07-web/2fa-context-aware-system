package com.example.a19dhjetor2024;

import android.content.Context;
import android.util.Log;

/**
 * Database Manager - Unified database operations handler
 * This class provides a single entry point for all database operations
 * and can be extended to sync with backend server
 */
public class DatabaseManager {
    private static final String TAG = "DatabaseManager";
    
    private DB localDB;
    private ApiService apiService;
    private boolean useBackend;
    private Context context;
    
    public DatabaseManager(Context context) {
        this.context = context;
        this.localDB = new DB(context);
        this.apiService = new ApiService(context);
        // TODO: Set this based on network availability or user preference
        this.useBackend = false; // Start with local only
    }
    
    /**
     * Enable/disable backend synchronization
     */
    public void setUseBackend(boolean useBackend) {
        this.useBackend = useBackend;
    }
    
    // ==================== USER OPERATIONS ====================
    
    /**
     * Sign up new user (hybrid: local + backend)
     */
    public boolean signUp(String name, String email, String password) {
        // Always save locally first
        boolean localSuccess = localDB.signUp(name, email, password);
        
        if (localSuccess && useBackend) {
            // Sync with backend
            ApiService.ApiResponse response = apiService.register(name, email, password);
            if (!response.success) {
                Log.w(TAG, "Backend sync failed for signup: " + response.message);
                // Continue with local success
            }
        }
        
        return localSuccess;
    }
    
    /**
     * Validate user credentials
     */
    public boolean validateUser(String email, String password) {
        // Try local first
        boolean localResult = localDB.validateUser(email, password);
        
        if (useBackend && localResult) {
            // Verify with backend
            ApiService.ApiResponse response = apiService.login(email, password);
            if (!response.success) {
                Log.w(TAG, "Backend validation failed: " + response.message);
                // Use local result
            }
        }
        
        return localResult;
    }
    
    /**
     * Check if user exists
     */
    public boolean userExists(String email) {
        return localDB.userExists(email);
    }
    
    /**
     * Check if account is verified
     */
    public boolean isAccountVerified(String email) {
        return localDB.isAccountVerified(email);
    }
    
    // ==================== DEVICE OPERATIONS ====================
    
    /**
     * Add trusted device (hybrid: local + backend)
     */
    public void addTrustedDevice(String email, String deviceFingerprint, 
                                String deviceName, String deviceModel) {
        // Save locally
        localDB.addTrustedDevice(email, deviceFingerprint, deviceName, deviceModel);
        
        if (useBackend) {
            // Sync with backend
            ApiService.ApiResponse response = apiService.addTrustedDevice(
                email, deviceFingerprint, deviceName, deviceModel);
            if (!response.success) {
                Log.w(TAG, "Backend sync failed for trusted device: " + response.message);
            }
        }
    }
    
    /**
     * Check if device is trusted
     */
    public boolean isDeviceTrusted(String email, String deviceFingerprint) {
        boolean localResult = localDB.isDeviceTrusted(email, deviceFingerprint);
        
        if (useBackend && !localResult) {
            // Check backend if not found locally
            // This would require a GET endpoint
            Log.d(TAG, "Checking backend for trusted device");
        }
        
        return localResult;
    }
    
    /**
     * Get trusted devices
     */
    public java.util.List<DB.TrustedDevice> getTrustedDevices(String email) {
        return localDB.getTrustedDevices(email);
    }
    
    /**
     * Remove trusted device
     */
    public void removeTrustedDevice(String email, String deviceFingerprint) {
        localDB.removeTrustedDevice(email, deviceFingerprint);
        
        if (useBackend) {
            // Sync removal with backend
            // Would need DELETE endpoint
            Log.d(TAG, "Syncing device removal with backend");
        }
    }
    
    // ==================== LOGIN ATTEMPTS ====================
    
    /**
     * Log login attempt (hybrid: local + backend)
     */
    public void logLoginAttempt(String email, String deviceFingerprint, 
                                String deviceModel, String networkType, 
                                String networkSSID, String ipAddress, 
                                String status, String method, String suspiciousReason) {
        // Save locally
        localDB.logLoginAttempt(email, deviceFingerprint, deviceModel, 
                               networkType, networkSSID, ipAddress, 
                               status, method, suspiciousReason);
        
        if (useBackend) {
            // Sync with backend
            ApiService.ApiResponse response = apiService.logLoginAttempt(
                email, deviceFingerprint, deviceModel, networkType, 
                networkSSID, ipAddress, status, method, suspiciousReason);
            if (!response.success) {
                Log.w(TAG, "Backend sync failed for login attempt: " + response.message);
            }
        }
    }
    
    /**
     * Get login attempts
     */
    public java.util.List<DB.LoginAttempt> getLoginAttempts(String email) {
        return localDB.getLoginAttempts(email);
    }
    
    // ==================== NETWORK OPERATIONS ====================
    
    /**
     * Update user network
     */
    public void updateUserNetwork(String email, String networkSSID) {
        localDB.updateUserNetwork(email, networkSSID);
    }
    
    /**
     * Get last network for user
     */
    public String getLastNetworkForUser(String email) {
        return localDB.getLastNetworkForUser(email);
    }
    
    // ==================== BLOCKED DEVICES ====================
    
    /**
     * Check if device is blocked
     */
    public boolean isDeviceBlocked(String email, String deviceFingerprint) {
        boolean localResult = localDB.isDeviceBlocked(email, deviceFingerprint);
        
        if (useBackend && !localResult) {
            // Check backend
            Log.d(TAG, "Checking backend for blocked device");
        }
        
        return localResult;
    }
    
    /**
     * Block device
     */
    public void blockDevice(String email, String deviceFingerprint) {
        localDB.blockDevice(email, deviceFingerprint);
        
        if (useBackend) {
            ApiService.ApiResponse response = apiService.blockDevice(email, deviceFingerprint);
            if (!response.success) {
                Log.w(TAG, "Backend sync failed for block device: " + response.message);
            }
        }
    }
    
    /**
     * Unblock device
     */
    public void unblockDevice(String email, String deviceFingerprint) {
        localDB.unblockDevice(email, deviceFingerprint);
    }
    
    // ==================== OTP OPERATIONS ====================
    
    /**
     * Generate and send OTP
     */
    public void logInUser(String email, String password) {
        localDB.logInUser(email, password);
    }
    
    /**
     * Get verification code
     */
    public String getVerificationCode(String email) {
        return localDB.getVerificationCode(email);
    }
    
    /**
     * Validate user (mark as verified)
     */
    public void validateTheUser(String email) {
        localDB.validateTheUser(email);
    }
    
    /**
     * Close database connections
     */
    public void close() {
        if (localDB != null) {
            localDB.close();
        }
    }
}

