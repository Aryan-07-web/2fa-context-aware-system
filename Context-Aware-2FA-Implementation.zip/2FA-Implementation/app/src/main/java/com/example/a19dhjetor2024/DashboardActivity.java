package com.example.a19dhjetor2024;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class DashboardActivity extends AppCompatActivity {
    private TextView trustedDevicesCount;
    private TextView suspiciousAttemptsCount;
    private TextView lastLoginText;
    private TextView lastNetworkText;
    private TextView deviceIntegrityText;
    private Button deviceManagementButton;
    private Button loginAttemptsButton;
    private Button profileButton;
    private Button logoutButton;
    private ApiService apiService;
    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);

        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        email = sharedPreferences.getString("loggedEmail", null);

        if (email == null) {
            // No logged in user, go to login
            startActivity(new Intent(this, Login.class));
            finish();
            return;
        }

        apiService = new ApiService(this);

        trustedDevicesCount = findViewById(R.id.trustedDevicesCount);
        suspiciousAttemptsCount = findViewById(R.id.suspiciousAttemptsCount);
        lastLoginText = findViewById(R.id.lastLoginText);
        lastNetworkText = findViewById(R.id.lastNetworkText);
        deviceIntegrityText = findViewById(R.id.deviceIntegrityText);
        deviceManagementButton = findViewById(R.id.deviceManagementButton);
        loginAttemptsButton = findViewById(R.id.loginAttemptsButton);
        profileButton = findViewById(R.id.profileButton);
        logoutButton = findViewById(R.id.logoutButton);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        loadDashboardData();

        deviceManagementButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, DeviceManagementActivity.class);
            startActivity(intent);
        });

        loginAttemptsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, LoginAttemptsActivity.class);
            startActivity(intent);
        });

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        logoutButton.setOnClickListener(v -> logout());
    }

    private void loadDashboardData() {
        // Show loading
        trustedDevicesCount.setText("Loading...");
        suspiciousAttemptsCount.setText("Loading...");
        
        // Load data on background thread
        new Thread(() -> {
            // Get trusted devices count from API
            ApiService.ApiResponse trustedResponse = apiService.getTrustedDevices(email);
            int trustedCount = 0;
            if (trustedResponse.success && trustedResponse.data != null && !trustedResponse.data.isEmpty()) {
                try {
                    JSONObject trustedJson = new JSONObject(trustedResponse.data);
                    JSONArray trustedArray = trustedJson.getJSONArray("data");
                    trustedCount = trustedArray.length();
                } catch (Exception e) {
                    android.util.Log.e("Dashboard", "Error parsing trusted devices: " + e.getMessage());
                }
            }
            
            final int finalTrustedCount = trustedCount;
            runOnUiThread(() -> {
                trustedDevicesCount.setText(String.valueOf(finalTrustedCount));
            });

            // Get login attempts from API
            ApiService.ApiResponse attemptsResponse = apiService.getLoginAttempts(email);
            int suspiciousCount = 0;
            String lastLogin = "Never";
            
            if (attemptsResponse.success && attemptsResponse.data != null && !attemptsResponse.data.isEmpty()) {
                try {
                    JSONObject attemptsJson = new JSONObject(attemptsResponse.data);
                    JSONArray attemptsArray = attemptsJson.getJSONArray("data");
                    
                    for (int i = 0; i < attemptsArray.length(); i++) {
                        JSONObject attempt = attemptsArray.getJSONObject(i);
                        
                        // Check if this is a suspicious attempt
                        boolean isSuspicious = false;
                        String status = attempt.optString("status", "");
                        String method = attempt.optString("method", "");
                        String suspiciousReason = attempt.optString("suspicious_reason", "");
                        
                        if (status.equals("Failed")) {
                            isSuspicious = true;
                        } else if (suspiciousReason != null && !suspiciousReason.isEmpty()) {
                            // Only mark as suspicious if it's NOT a trusted device login
                            if (!method.contains("Trusted Device")) {
                                isSuspicious = true;
                            }
                        }
                        
                        if (isSuspicious) {
                            suspiciousCount++;
                        }
                        
                        // Get last successful login
                        if (lastLogin.equals("Never") && status.equals("Success")) {
                            lastLogin = attempt.optString("timestamp", "Never");
                        }
                    }
                } catch (Exception e) {
                    android.util.Log.e("Dashboard", "Error parsing login attempts: " + e.getMessage());
                }
            }
            
            final int finalSuspiciousCount = suspiciousCount;
            final String finalLastLogin = lastLogin;
            runOnUiThread(() -> {
                suspiciousAttemptsCount.setText(String.valueOf(finalSuspiciousCount));
                lastLoginText.setText("Last Login: " + finalLastLogin);
            });

            // Get last network from API
            ApiService.ApiResponse networkResponse = apiService.getLastNetwork(email);
            String lastNetwork = "Unknown";
            if (networkResponse.success && networkResponse.data != null && !networkResponse.data.isEmpty()) {
                try {
                    JSONObject networkJson = new JSONObject(networkResponse.data);
                    String networkSSID = networkJson.optString("networkSSID", null);
                    if (networkSSID != null && !networkSSID.isEmpty()) {
                        lastNetwork = networkSSID;
                    }
                } catch (Exception e) {
                    android.util.Log.e("Dashboard", "Error parsing network: " + e.getMessage());
                }
            }
            
            final String finalLastNetwork = lastNetwork;
            runOnUiThread(() -> {
                lastNetworkText.setText("Last Network: " + finalLastNetwork);
            });

            // Check device integrity (this is local, can run on main thread)
            runOnUiThread(() -> {
                DeviceIntegrityChecker.IntegrityResult integrity = 
                    DeviceIntegrityChecker.checkDeviceIntegrity(this);
                if (integrity.isSuspicious) {
                    deviceIntegrityText.setText("Device Status: Suspicious");
                } else {
                    deviceIntegrityText.setText("Device Status: Secure");
                }
            });
        }).start();
    }

    private void logout() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        Session.clearSession();

        Intent intent = new Intent(DashboardActivity.this, Login.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardData();
    }
}

