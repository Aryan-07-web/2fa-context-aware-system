const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Database connection
const pool = new Pool({
    user: process.env.DB_USER ,
    host: process.env.DB_HOST ,
    database: process.env.DB_NAME ,
    password: process.env.DB_PASSWORD ,
    port: process.env.DB_PORT || 5432,
});

// Initialize database tables
async function initializeDatabase() {
    try {
        // Users table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                full_name VARCHAR(255),
                password_hash VARCHAR(255) NOT NULL,
                salt VARCHAR(255),
                is_verified BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Trusted Devices table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS trusted_devices (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                device_fingerprint VARCHAR(255) NOT NULL,
                device_name VARCHAR(255),
                device_model VARCHAR(255),
                last_login TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, device_fingerprint)
            )
        `);

        // Login Attempts table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS login_attempts (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                device_fingerprint VARCHAR(255),
                device_model VARCHAR(255),
                network_type VARCHAR(50),
                network_ssid VARCHAR(255),
                ip_address VARCHAR(45),
                status VARCHAR(50),
                method VARCHAR(50),
                suspicious_reason TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // User Networks table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS user_networks (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                network_ssid VARCHAR(255),
                last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, network_ssid)
            )
        `);

        // Blocked Devices table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS blocked_devices (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                device_fingerprint VARCHAR(255) NOT NULL,
                blocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, device_fingerprint)
            )
        `);

        // Security Questions table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS security_questions (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                question_1 TEXT NOT NULL,
                answer_1 TEXT NOT NULL,
                question_2 TEXT NOT NULL,
                answer_2 TEXT NOT NULL,
                question_3 TEXT NOT NULL,
                answer_3 TEXT NOT NULL,
                question_4 TEXT NOT NULL,
                answer_4 TEXT NOT NULL,
                question_5 TEXT NOT NULL,
                answer_5 TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id)
            )
        `);

        console.log('Database tables initialized successfully');
    } catch (error) {
        console.error('Error initializing database:', error);
    }
}

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'Server is running' });
});

// Register endpoint
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, password, securityQuestions } = req.body;

        console.log('Registration request received:', { name, email, hasPassword: !!password, securityQuestions: securityQuestions ? securityQuestions.length : 0 });

        if (!name || !email || !password) {
            return res.status(400).json({ success: false, message: 'Missing required fields: name, email, or password' });
        }

        if (!securityQuestions) {
            return res.status(400).json({ success: false, message: 'Security questions are required' });
        }

        if (!Array.isArray(securityQuestions)) {
            return res.status(400).json({ success: false, message: 'Security questions must be an array' });
        }

        if (securityQuestions.length !== 5) {
            return res.status(400).json({ success: false, message: `Expected 5 security questions, received ${securityQuestions.length}` });
        }

        // Validate each question has question and answer
        for (let i = 0; i < securityQuestions.length; i++) {
            const sq = securityQuestions[i];
            if (!sq || typeof sq !== 'object') {
                return res.status(400).json({ success: false, message: `Security question ${i + 1} is invalid` });
            }
            if (!sq.question || !sq.answer) {
                return res.status(400).json({ success: false, message: `Security question ${i + 1} is missing question or answer` });
            }
        }

        // Check if user already exists
        const existingUser = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (existingUser.rows.length > 0) {
            return res.status(400).json({ success: false, message: 'User already exists' });
        }

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const passwordHash = await bcrypt.hash(password, salt);

        // Insert user (not verified yet - will be verified after security questions)
        const result = await pool.query(
            'INSERT INTO users (email, full_name, password_hash, salt, is_verified) VALUES ($1, $2, $3, $4, $5) RETURNING id, email',
            [email, name, passwordHash, salt, false]
        );

        const userId = result.rows[0].id;

        // Hash answers for security (async)
        const hashedAnswers = [];
        for (const sq of securityQuestions) {
            const hashedAnswer = await bcrypt.hash(sq.answer.toLowerCase().trim(), 10);
            hashedAnswers.push({
                question: sq.question,
                answer: hashedAnswer
            });
        }

        // Store security questions
        await pool.query(
            `INSERT INTO security_questions (user_id, question_1, answer_1, question_2, answer_2, 
             question_3, answer_3, question_4, answer_4, question_5, answer_5) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
            [
                userId,
                hashedAnswers[0].question, hashedAnswers[0].answer,
                hashedAnswers[1].question, hashedAnswers[1].answer,
                hashedAnswers[2].question, hashedAnswers[2].answer,
                hashedAnswers[3].question, hashedAnswers[3].answer,
                hashedAnswers[4].question, hashedAnswers[4].answer
            ]
        );

        res.json({
            success: true,
            message: 'User registered successfully. Please answer security questions to verify.',
            data: { userId: userId, email: email }
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ success: false, message: 'Registration failed', error: error.message });
    }
});

// Login endpoint
app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ success: false, message: 'Email and password required' });
        }

        // Get user
        const userResult = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        const user = userResult.rows[0];

        // Check if verified
        if (!user.is_verified) {
            return res.status(401).json({ success: false, message: 'Please verify your email first' });
        }

        // Verify password
        const isValidPassword = await bcrypt.compare(password, user.password_hash);
        if (!isValidPassword) {
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        // Generate JWT token
        const token = jwt.sign(
            { userId: user.id, email: user.email },
            process.env.JWT_SECRET || 'your-secret-key-change-this',
            { expiresIn: '7d' }
        );

        res.json({
            success: true,
            message: 'Login successful',
            data: { token, user: { id: user.id, email: user.email, name: user.full_name } }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ success: false, message: 'Login failed', error: error.message });
    }
});


// Evaluate context endpoint
app.post('/api/security/evaluate-context', async (req, res) => {
    try {
        const { email, deviceFingerprint, deviceModel, networkType, networkSSID, ipAddress } = req.body;

        // Get user
        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const userId = userResult.rows[0].id;

        // Check if device is blocked
        const blockedResult = await pool.query(
            'SELECT * FROM blocked_devices WHERE user_id = $1 AND device_fingerprint = $2',
            [userId, deviceFingerprint]
        );

        if (blockedResult.rows.length > 0) {
            return res.json({
                success: true,
                requiresOTP: true,
                isTrustedDevice: false,
                suspiciousReason: 'Device is blocked',
                isBlocked: true
            });
        }

        // Check if device is trusted
        const trustedResult = await pool.query(
            'SELECT * FROM trusted_devices WHERE user_id = $1 AND device_fingerprint = $2',
            [userId, deviceFingerprint]
        );

        const isTrustedDevice = trustedResult.rows.length > 0;

        // Get last network
        const networkResult = await pool.query(
            'SELECT network_ssid FROM user_networks WHERE user_id = $1 ORDER BY last_used DESC LIMIT 1',
            [userId]
        );

        let requiresOTP = !isTrustedDevice;
        let suspiciousReason = '';

        if (!isTrustedDevice) {
            suspiciousReason = 'New device detected';
        } else if (networkResult.rows.length > 0) {
            const lastNetwork = networkResult.rows[0].network_ssid;
            if (networkType === 'WiFi' && networkSSID && lastNetwork !== networkSSID) {
                requiresOTP = true;
                suspiciousReason = 'Unusual network detected';
            }
        }

        res.json({
            success: true,
            requiresOTP: requiresOTP,
            isTrustedDevice: isTrustedDevice,
            suspiciousReason: suspiciousReason,
            isBlocked: false
        });
    } catch (error) {
        console.error('Context evaluation error:', error);
        res.status(500).json({ success: false, message: 'Context evaluation failed', error: error.message });
    }
});

// Add trusted device endpoint
app.post('/api/devices/trust', async (req, res) => {
    try {
        const { email, deviceFingerprint, deviceName, deviceModel } = req.body;

        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const userId = userResult.rows[0].id;

        // Check if already exists
        const existing = await pool.query(
            'SELECT * FROM trusted_devices WHERE user_id = $1 AND device_fingerprint = $2',
            [userId, deviceFingerprint]
        );

        if (existing.rows.length > 0) {
            // Update last login
            await pool.query(
                'UPDATE trusted_devices SET last_login = CURRENT_TIMESTAMP WHERE user_id = $1 AND device_fingerprint = $2',
                [userId, deviceFingerprint]
            );
        } else {
            // Check device count (max 3)
            const countResult = await pool.query(
                'SELECT COUNT(*) FROM trusted_devices WHERE user_id = $1',
                [userId]
            );

            if (parseInt(countResult.rows[0].count) >= 3) {
                // Remove least recently used
                await pool.query(
                    'DELETE FROM trusted_devices WHERE id = (SELECT id FROM trusted_devices WHERE user_id = $1 ORDER BY last_login ASC LIMIT 1)',
                    [userId]
                );
            }

            // Insert new device
            await pool.query(
                'INSERT INTO trusted_devices (user_id, device_fingerprint, device_name, device_model, last_login) VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)',
                [userId, deviceFingerprint, deviceName, deviceModel]
            );
        }

        res.json({ success: true, message: 'Device added to trusted devices' });
    } catch (error) {
        console.error('Add trusted device error:', error);
        res.status(500).json({ success: false, message: 'Failed to add trusted device', error: error.message });
    }
});

// Log login attempt endpoint
app.post('/api/security/login-attempts', async (req, res) => {
    try {
        const { email, deviceFingerprint, deviceModel, networkType, networkSSID, ipAddress, status, method, suspiciousReason } = req.body;

        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const userId = userResult.rows[0].id;

        await pool.query(
            'INSERT INTO login_attempts (user_id, device_fingerprint, device_model, network_type, network_ssid, ip_address, status, method, suspicious_reason) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
            [userId, deviceFingerprint, deviceModel, networkType, networkSSID, ipAddress, status, method, suspiciousReason]
        );

        res.json({ success: true, message: 'Login attempt logged' });
    } catch (error) {
        console.error('Log login attempt error:', error);
        res.status(500).json({ success: false, message: 'Failed to log login attempt', error: error.message });
    }
});

// Block device endpoint
app.post('/api/security/block-device', async (req, res) => {
    try {
        const { email, deviceFingerprint } = req.body;

        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const userId = userResult.rows[0].id;

        await pool.query(
            'INSERT INTO blocked_devices (user_id, device_fingerprint) VALUES ($1, $2) ON CONFLICT (user_id, device_fingerprint) DO NOTHING',
            [userId, deviceFingerprint]
        );

        res.json({ success: true, message: 'Device blocked successfully' });
    } catch (error) {
        console.error('Block device error:', error);
        res.status(500).json({ success: false, message: 'Failed to block device', error: error.message });
    }
});

// Get login attempts endpoint
app.get('/api/security/login-attempts', async (req, res) => {
    try {
        const { email } = req.query;

        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const userId = userResult.rows[0].id;

        const result = await pool.query(
            'SELECT * FROM login_attempts WHERE user_id = $1 ORDER BY timestamp DESC LIMIT 50',
            [userId]
        );

        res.json({ success: true, data: result.rows });
    } catch (error) {
        console.error('Get login attempts error:', error);
        res.status(500).json({ success: false, message: 'Failed to get login attempts', error: error.message });
    }
});

// Check if user exists
app.get('/api/auth/user-exists', async (req, res) => {
    try {
        const { email } = req.query;
        const result = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        res.json({ success: true, exists: result.rows.length > 0 });
    } catch (error) {
        console.error('Check user exists error:', error);
        res.status(500).json({ success: false, message: 'Failed to check user', error: error.message });
    }
});

// Check if account is verified
app.get('/api/auth/account-verified', async (req, res) => {
    try {
        const { email } = req.query;
        const result = await pool.query('SELECT is_verified FROM users WHERE email = $1', [email]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        res.json({ success: true, verified: result.rows[0].is_verified });
    } catch (error) {
        console.error('Check account verified error:', error);
        res.status(500).json({ success: false, message: 'Failed to check verification', error: error.message });
    }
});

// Get security questions for verification
app.get('/api/auth/security-questions', async (req, res) => {
    try {
        const { email } = req.query;
        
        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        const userId = userResult.rows[0].id;
        
        const questionsResult = await pool.query(
            'SELECT question_1, question_2, question_3, question_4, question_5 FROM security_questions WHERE user_id = $1',
            [userId]
        );
        
        if (questionsResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Security questions not found' });
        }
        
        const questions = questionsResult.rows[0];
        res.json({
            success: true,
            data: {
                questions: [
                    questions.question_1,
                    questions.question_2,
                    questions.question_3,
                    questions.question_4,
                    questions.question_5
                ]
            }
        });
    } catch (error) {
        console.error('Get security questions error:', error);
        res.status(500).json({ success: false, message: 'Failed to get security questions', error: error.message });
    }
});

// Verify security questions endpoint
app.post('/api/auth/verify-security-questions', async (req, res) => {
    try {
        const { email, answers } = req.body;
        
        if (!answers || !Array.isArray(answers) || answers.length !== 5) {
            return res.status(400).json({ success: false, message: 'All 5 answers are required' });
        }
        
        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        const userId = userResult.rows[0].id;
        
        // Get stored answers
        const questionsResult = await pool.query(
            'SELECT answer_1, answer_2, answer_3, answer_4, answer_5 FROM security_questions WHERE user_id = $1',
            [userId]
        );
        
        if (questionsResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Security questions not found' });
        }
        
        const storedAnswers = questionsResult.rows[0];
        const storedHashes = [
            storedAnswers.answer_1,
            storedAnswers.answer_2,
            storedAnswers.answer_3,
            storedAnswers.answer_4,
            storedAnswers.answer_5
        ];
        
        // Verify all answers (case-insensitive, trimmed)
        let allCorrect = true;
        for (let i = 0; i < 5; i++) {
            const providedAnswer = answers[i].toLowerCase().trim();
            const isCorrect = await bcrypt.compare(providedAnswer, storedHashes[i]);
            if (!isCorrect) {
                allCorrect = false;
                break;
            }
        }
        
        if (!allCorrect) {
            return res.status(400).json({ success: false, message: 'One or more answers are incorrect' });
        }
        
        // Mark user as verified
        await pool.query('UPDATE users SET is_verified = TRUE WHERE id = $1', [userId]);
        
        res.json({ success: true, message: 'Security questions verified successfully' });
    } catch (error) {
        console.error('Security questions verification error:', error);
        res.status(500).json({ success: false, message: 'Verification failed', error: error.message });
    }
});

// Get trusted devices
app.get('/api/devices/trust', async (req, res) => {
    try {
        const { email } = req.query;
        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        const userId = userResult.rows[0].id;
        
        const result = await pool.query(
            'SELECT * FROM trusted_devices WHERE user_id = $1 ORDER BY last_login DESC',
            [userId]
        );
        
        res.json({ success: true, data: result.rows });
    } catch (error) {
        console.error('Get trusted devices error:', error);
        res.status(500).json({ success: false, message: 'Failed to get trusted devices', error: error.message });
    }
});

// Check if device is trusted
app.get('/api/devices/trust-check', async (req, res) => {
    try {
        const { email, deviceFingerprint } = req.query;
        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        const userId = userResult.rows[0].id;
        
        const result = await pool.query(
            'SELECT * FROM trusted_devices WHERE user_id = $1 AND device_fingerprint = $2',
            [userId, deviceFingerprint]
        );
        
        res.json({ success: true, isTrusted: result.rows.length > 0 });
    } catch (error) {
        console.error('Check device trusted error:', error);
        res.status(500).json({ success: false, message: 'Failed to check device', error: error.message });
    }
});

// Check if device is blocked
app.get('/api/security/block-check', async (req, res) => {
    try {
        const { email, deviceFingerprint } = req.query;
        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        const userId = userResult.rows[0].id;
        
        const result = await pool.query(
            'SELECT * FROM blocked_devices WHERE user_id = $1 AND device_fingerprint = $2',
            [userId, deviceFingerprint]
        );
        
        res.json({ success: true, isBlocked: result.rows.length > 0 });
    } catch (error) {
        console.error('Check device blocked error:', error);
        res.status(500).json({ success: false, message: 'Failed to check block status', error: error.message });
    }
});

// Get last network
app.get('/api/security/last-network', async (req, res) => {
    try {
        const { email } = req.query;
        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        const userId = userResult.rows[0].id;
        
        const result = await pool.query(
            'SELECT network_ssid FROM user_networks WHERE user_id = $1 ORDER BY last_used DESC LIMIT 1',
            [userId]
        );
        
        if (result.rows.length === 0) {
            return res.json({ success: true, networkSSID: null });
        }
        
        res.json({ success: true, networkSSID: result.rows[0].network_ssid });
    } catch (error) {
        console.error('Get last network error:', error);
        res.status(500).json({ success: false, message: 'Failed to get network', error: error.message });
    }
});

// Update user network
app.post('/api/security/update-network', async (req, res) => {
    try {
        const { email, networkSSID } = req.body;
        const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        const userId = userResult.rows[0].id;
        
        await pool.query(
            'INSERT INTO user_networks (user_id, network_ssid) VALUES ($1, $2) ON CONFLICT (user_id, network_ssid) DO UPDATE SET last_used = CURRENT_TIMESTAMP',
            [userId, networkSSID]
        );
        
        res.json({ success: true, message: 'Network updated' });
    } catch (error) {
        console.error('Update network error:', error);
        res.status(500).json({ success: false, message: 'Failed to update network', error: error.message });
    }
});

// Start server
async function startServer() {
    await initializeDatabase();
    app.listen(PORT, '0.0.0.0', () => {
        console.log(`Server is running on http://0.0.0.0:${PORT}`);
        console.log(`Health check: http://0.0.0.0:${PORT}/api/health`);
    });
}

startServer().catch(console.error);

